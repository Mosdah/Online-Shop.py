from django.shortcuts import redirect, render
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa

from django.views import View, generic
from Shoppingcart.models import ShoppingCart
from .forms import GameForm, CommentForm, SearchForm
from .models import Game, Comment


def game_list(request):
    print('I am in game_list')
    context = {'all_the_games': Game.objects.all()}
    return render(request, 'game-list.html', context)


def game_detail(request, **kwargs):
    print(kwargs)
    game_id = kwargs['pk']
    game = Game.objects.get(id=game_id)
    user = request.user
    comments = Comment.objects.filter(game=game)

    context = {'that_one_game': game,
               'comments_for_that_one_game': comments,
               'comment_form': CommentForm,
               'alreadyCommented': False
               }

    if request.method == 'POST':
        myuser = request.user
        ShoppingCart.add_item(myuser, game)
        form = CommentForm(request.POST)
        form.instance.user = request.user
        form.instance.game = game
        if form.is_valid():
            form.save()
        else:
            print(form.errors)
        return redirect('game-detail', pk=game_id)

    else:
        if comments:
            comment = comments.first()
            print("first")
            if comment.commentOnce(user):
                print("second")
                context = {'that_one_game': game,
                           'comments_for_that_one_game': comments,
                           'comment_form': CommentForm,
                           'alreadyCommented': True,
                           'user': user
                           }
            else:
                context = {'that_one_game': game,
                           'comments_for_that_one_game': comments,
                           'comment_form': CommentForm,
                           'alreadyCommented': False,
                           'user': user
                           }

    return render(request, 'game-detail.html', context)


def game_search(request):
    if request.method == 'POST':

        search_string_title = request.POST['title']
        if search_string_title:
            games_found = Game.objects.filter(title__contains=search_string_title)

        search_string_description = request.POST['description']
        if search_string_description:
            games_found = Game.objects.filter(description__contains=search_string_description)

        form_in_function_based_view = SearchForm()
        context = {'form': form_in_function_based_view,
                   'games_found': games_found,
                   'show_results': True}
        return render(request, 'game-search.html', context)

    else:
        form_in_function_based_view = SearchForm()
        context = {'form': form_in_function_based_view,
                   'show_results': False}
        return render(request, 'game-search.html', context)


def comment_update(request, **kwargs):
    if request.method == 'POST':

        comment_id = kwargs['pk']
        form = CommentForm(request.POST)
        new_text = request.POST['text']
        new_rating = request.POST['rating']
        print("FIND: " + new_text + " " + new_rating)
        comment = Comment.objects.get(id=comment_id)
        print(comment)
        if form.is_valid():
            comment.text = new_text
            comment.rating = new_rating
            comment.save()
        print(str(comment_id), " :: ", comment)

        return redirect('game-list')
    else:
        form = CommentForm
        print("I am in GET Update")
        comment_id = kwargs['pk']
        comment = Comment.objects.get(id=comment_id)
        context = {'comment': comment,
                   'comment_form': form,
                   'text': comment.text,
                   }
        return render(request, 'comment-update.html', context)


def comment_delete(request, **kwargs):
    if request.method == 'POST':

        print("Delete Comment")
        comment_id = kwargs['pk']
        user = request.user
        comment = Comment.objects.get(id=comment_id)
        print(str(comment_id), " :: ", comment)
        comment.delete()
        return redirect('game-list')

    else:
        print("I am in GET Delete")
        comment_id = kwargs['pk']
        comment = Comment.objects.get(id=comment_id)
        context = {'comment': comment}
        return render(request, 'comment-delete.html', context)


def game_create(request):
    if request.method == 'POST' and request.FILES:
        print("I am in POST")
        form_in_my_function_based_view = GameForm(request.POST, request.FILES)
        form_in_my_function_based_view.instance.user = request.user
        if form_in_my_function_based_view.is_valid():
            form_in_my_function_based_view.save()

        else:
            pass
            print(form_in_my_function_based_view.errors)

        return redirect('game-list')

    else:
        print("I am in GET")
        form_in_my_function_based_view = GameForm()
        context = {'form': form_in_my_function_based_view}
        return render(request, 'game-create.html', context)


def game_delete(request, **kwargs):
    if request.method == 'POST':

        print("Delete Game")
        game_id = kwargs['pk']
        delete_one_game_in_my_function_based_view = Game.objects.get(id=game_id)
        print(str(game_id), " :: ", delete_one_game_in_my_function_based_view)
        delete_one_game_in_my_function_based_view.delete()
        return redirect('game-list')

    else:
        print("I am in GET Delete")
        game_id = kwargs['pk']
        that_one_game_in_my_function_based_view = Game.objects.get(id=game_id)
        context = {'game': that_one_game_in_my_function_based_view}
        return render(request, 'game-delete.html', context)


def game_update(request, **kwargs):
    if request.method == 'POST':

        game_id = kwargs['pk']
        form = GameForm(request.POST)
        new_text = request.POST['title']
        print("FIND: " + new_text)
        game = Game.objects.get(id=game_id)
        print(game)
        if form.is_valid():
            game.title = new_text
            game.save()
        print(str(game_id), " :: ", game)

        return redirect('game-list')
    else:
        form = GameForm
        print("I am in GET Update")
        game_id = kwargs['pk']
        game = Comment.objects.get(id=game_id)
        context = {'title': game,
                   'title_form': form,
                   'text': game.text,
                   }
        return render(request, 'game-update.html', context)


# def game_update(request, pk):
        #     if request.method == 'POST':
        # print("Delete Game")
        # game_id = kwargs['pk']
        # update_one_game_in_my_function_based_view = Game.objects.get(id=game_id)
        # print(str(game_id), " :: ", update_one_game_in_my_function_based_view)
        # update_one_game_in_my_function_based_view.delete()
        #   form = GameForm(request.POST, instance=game)
        #   if form.is_valid():
        #       form.save()
    #       return redirect('game-list')
    # else:
        #   print("I am in Update Game")
        # game_id = kwargs['pk']
        # that_one_game_in_my_function_based_view = Game.objects.get(id=game_id)
        # context = {'game': that_one_game_in_my_function_based_view}
        # return render(request, 'game-update.html', context)


def vote(request, pk: str, up_or_down: str, pk2: str):
    comment = Comment.objects.get(id=int(pk2))
    print(comment.id)
    user = request.user
    comment.vote(user, up_or_down)
    return redirect('game-detail', pk=pk)


def report(request, pk: str, pk2: str):
    rep = Comment.objects.get(id=int(pk2))
    print("String: " + str(rep.report))
    number = rep.report
    rep.report = number + 1
    rep.save(update_fields=['report'])
    return redirect('game-detail', pk=pk)


##################################################################
def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None


# Opens up page as PDF
class ViewPDF(View):
    def get(self, request, *args, **kwargs):
        game_id = kwargs['pk']
        game = Game.objects.get(id=game_id)
        titel = game.title
        beschreibung = game.description
        genre = game.genre
        fsk = game.fsk
        price = game.price
        published = game.date_published
        data = {
            "Title": titel,
            "Genre": genre,
            "Beschreibung": beschreibung,
            "Altersfreigabe": fsk,
            "Price": price,
            "published": published
        }
        pdf = render_to_pdf('pdf_template.html', data)
        return HttpResponse(pdf, content_type='application/pdf')


# Automaticly downloads to PDF file
class DownloadPDF(View):
    def get(self, request, *args, **kwargs):
        game_id = kwargs['pk']
        game = Game.objects.get(id=game_id)
        title = game.title
        bild = game.product_picture.url

        genre = game.genre
        beschreibung = game.description
        fsk = game.fsk
        price = game.price
        published = game.date_published
        data = {
            "Title": title,
            "Bild": bild,
            "Genre": genre,
            "Beschreibung": beschreibung,
            "Altersfreigabe": fsk,
            "Price": price,
            "published": published
        }

        pdf = render_to_pdf('pdf_template.html', data)
        response = HttpResponse(pdf, content_type='application/pdf')
        filename = "Gamedetail_%s.pdf" % (title)
        content = "attachment; filename='%s'" % (filename)
        response['Content-Disposition'] = content
        return response


class GameListView(generic.ListView):
    model = Game
    context_object_name = 'all_games'
    template_name = 'game-detail.html'


def index(request):
    context = {}
    return render(request, 'game-detail.html', context)
