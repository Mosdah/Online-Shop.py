from django import forms
from .models import Game, Comment


class GameForm(forms.ModelForm):
    class Meta:
        model = Game
        fields = ['title', 'fsk', 'genre', 'description', 'price', 'date_published', 'product_picture']
        widgets = {
            'genre': forms.Select(choices=Game.GAME_TYPES),
            'fsk': forms.Select(choices=Game.GAME_FSK),
            'user': forms.HiddenInput(),
        }


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text', 'rating']
        widgets = {
            'user': forms.HiddenInput(),
            'game': forms.HiddenInput(),
        }


class SearchForm(forms.ModelForm):
    title = forms.CharField(required=False)
    description = forms.CharField(required=False)

    class Meta:
        model = Game
        fields = ['title', 'description']
