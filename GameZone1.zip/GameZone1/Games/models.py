from datetime import datetime

from django.conf import settings
from django.db import models
from django.contrib.auth.models import User
from django.db.models import ManyToManyField, IntegerField

from Useradmin.models import MyUser


class Game(models.Model):
    GAME_TYPES = [
        ('Ego-Shooter', 'Ego-Shooter'),
        ('Rollenspiel', 'Rollenspiel'),
        ('Abenteuerspiel', 'Abenteuerspiel'),
        ('Lernspiel', 'Lernspiel'),
        ('Sportspiel', 'Sportspiel')
    ]
    GAME_FSK = [
        ('FSK0', '0'),
        ('FSK6', '6'),
        ('FSK12', '12'),
        ('FSK16', '16'),
        ('FSK18', '18'),
    ]
    title = models.CharField(max_length=100)
    description = models.CharField(max_length=100,
                                   blank=True)
    fsk = models.CharField(max_length=100,
                           choices=GAME_FSK,
                           )
    date_published = models.DateTimeField(blank=True,
                                          default=datetime.now(),
                                          )
    genre = models.CharField(max_length=100,
                             choices=GAME_TYPES,
                             )
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE,
                             related_name='users',
                             related_query_name='user',
                             )
    price = models.DecimalField(decimal_places=2, max_digits=10, default=0.0)

    product_picture = models.ImageField(upload_to='product_pictures/', blank=True, null=True,)

    class Meta:
        ordering = ['title', 'fsk', 'description', 'genre']
        verbose_name = 'Game'
        verbose_name_plural = 'Games'

    def get_full_title(self):
        return_string = self.title
        return return_string

    def __str__(self):
        return self.title + ' (' + self.user.username + ')'

    def __repr__(self):
        return self.get_full_title() + ' / ' + self.user.username + ' / ' + self.genre


class Comment(models.Model):
    Comment_Rating = [
        ('1', '1'),
        ('2', '2'),
        ('3', '3'),
        ('4', '4'),
        ('5', '5'),
    ]
    rating = models.CharField(max_length=10,
                              choices=Comment_Rating,
                              default=1,
                              )
    votes = []
    text = models.TextField(max_length=500)
    timestamp = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    report = models.IntegerField(blank=True, null=True, default=1)

    def commentOnce(self, user):
        comment = Comment.objects.filter(user=user, game=self.game)
        print("Count: " + str(comment.count()))
        if comment.count() >= 1:
            print("True")
            return True
        else:
            print("False")

            return False

    def get_downvotes(self):
        downvotes = Vote.objects.filter(up_or_down='D',
                                        comment=self)

        return downvotes

    def get_downvotes_count(self):
        return len(self.get_downvotes())

    def get_upvotes(self):
        upvotes = Vote.objects.filter(up_or_down='U',
                                      comment=self)

        return upvotes

    def get_upvotes_count(self):
        return len(self.get_upvotes())

    def onlyOnceUp(self, user):
        votes = Vote.objects.filter(user=user, comment=self, up_or_down='U')

        if votes:
            return True
        else:
            return False

    def onlyOnceDown(self, user):
        votes = Vote.objects.filter(user=user, comment=self, up_or_down='D')

        if votes:
            return True
        else:
            return False

    def vote(self, user, up_or_down):

        if self.onlyOnceUp(user):
            Vote.objects.filter(user=user, comment=self, up_or_down='U').delete()  # split this up

            if up_or_down == 'down':
                vote = Vote.objects.create(up_or_down='D',
                                           user=user,
                                           comment=self
                                           )

        elif self.onlyOnceDown(user):
            Vote.objects.filter(user=user, comment=self, up_or_down='D').delete()

            if up_or_down == 'up':
                vote = Vote.objects.create(up_or_down='U',
                                           user=user,
                                           comment=self
                                           )
        else:
            U_or_D = 'U'
            if up_or_down == 'down':
                U_or_D = 'D'
            vote = Vote.objects.create(up_or_down=U_or_D,
                                       user=user,
                                       comment=self
                                       )

    class Meta:
        ordering = ['timestamp']
        verbose_name = 'Comment'
        verbose_name_plural = 'Comments'

    def get_comment_prefix(self):
        if len(self.text) > 50:
            return self.text[:50] + '...'
        else:
            return self.text

    def __str__(self):
        return self.get_comment_prefix() + ' (' + self.user.username + ')'

    def __repr__(self):
        return self.get_comment_prefix() + ' (' + self.user.username + ' / ' + str(self.timestamp) + ')'


class Vote(models.Model):
    VOTE_TYPES = [('U', 'up'),
                  ('D', 'down'),
                  ]

    up_or_down = models.CharField(max_length=1,
                                  choices=VOTE_TYPES,
                                  )
    timestamp = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE)
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE)

    def __str__(self):
        return self.up_or_down + ' on ' + self.comment.text + ' by ' + self.user.username
