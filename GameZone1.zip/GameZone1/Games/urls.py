from django.urls import path
from . import views

urlpatterns = [
    path('show/', views.game_list, name='game-list'),
    path('show/<int:pk>/', views.game_detail, name='game-detail'),
    path('add/', views.game_create, name='game-create'),
    path('show/<int:pk>/vote/<str:up_or_down>/<int:pk2>/', views.vote, name='game-vote'), #comment id
    path('delete/<int:pk>/', views.game_delete, name='game-delete'),
    path('update/<int:pk>/', views.game_update, name='game-update'),
    path('comment/delete/<int:pk>/', views.comment_delete, name='comment-delete'),
    path('comment/update/<int:pk>/', views.comment_update, name='comment-update'),
    path('search/', views.game_search, name='game-search'),
    path('show/<int:pk>/report/<int:pk2>/', views.report, name='comment-report'),
    path('pdf_view/<int:pk>/', views.ViewPDF.as_view(), name="pdf_view"),
    path('pdf_download/<int:pk>/', views.DownloadPDF.as_view(), name="pdf_download"),

]
